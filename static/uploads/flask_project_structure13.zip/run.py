# Run the app
