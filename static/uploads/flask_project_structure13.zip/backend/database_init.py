# Initialize sample database data
